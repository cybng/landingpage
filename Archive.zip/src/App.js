import React from 'react'
import Header from "./component/Header";
import Content from "./component/Content";
import MidContent from "./component/MidContent";
import Mid from "./component/Mid";

export default function App() {
  return (
    <div>
    <Header/>
    <Content/>
    <MidContent/>
    <Mid/> 
      
    </div>
  )
}